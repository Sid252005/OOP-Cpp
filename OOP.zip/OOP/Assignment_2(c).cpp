#include<iostream>
using namespace std;
int main()
{
	cout<<"\nEnter Number:";
	int a,i;
	cin>>a;
	for(i=1;i<=10;i++)
	{
		cout<<"\n";
		cout<<a*i;
	}
}
